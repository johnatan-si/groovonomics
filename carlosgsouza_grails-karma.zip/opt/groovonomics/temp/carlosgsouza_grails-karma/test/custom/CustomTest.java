import org.junit.Test;

public class CustomTest {

	@Test
	public void fail() {
		// throw new RuntimeException("fail");
	}
}
